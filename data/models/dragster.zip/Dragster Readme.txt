Sostituite la linea del BANDITO nel vehicles.ide con questa


568, 	bandito, 	bandito, 	car, 		BANDITO, 	BANDITO,	null,	ignore,		4,	0,	0,		0, 0.7, 1.0,		1
